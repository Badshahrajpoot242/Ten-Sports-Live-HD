# Ten Sports Live HD — GitHub se APK Banane ka Tarika

## Step 1 — GitHub Repo Banao

1. GitHub.com par jao
2. New Repository banao (naam kuch bhi rakho, e.g. `ten-sports-live-hd`)
3. Private ya Public — apni marzi

## Step 2 — Expo Account Banao

1. https://expo.dev par jao aur free account banao
2. Login ke baad: https://expo.dev/settings/access-tokens par jao
3. **"Create Token"** click karo, naam rakho `GITHUB_ACTIONS`
4. Token copy kar lo (ek baar hi dikhega)

## Step 3 — GitHub Secret Set Karo

1. Apne GitHub repo mein jao → **Settings** → **Secrets and variables** → **Actions**
2. **"New repository secret"** click karo:
   - Name: `EXPO_TOKEN`
   - Value: (jo token copy kiya tha)
3. Save karo

## Step 4 — Code GitHub par Push Karo

```bash
git init
git add .
git commit -m "Ten Sports Live HD"
git remote add origin https://github.com/TUMHARA_USERNAME/REPO_NAAM.git
git push -u origin main
```

## Step 5 — APK Build Karo

**Automatic:** Jab bhi `main` branch par push karo, APK automatically build hoga.

**Manual:** GitHub repo → **Actions** tab → **Build Android APK** → **Run workflow**

## Step 6 — APK Download Karo

1. GitHub → **Actions** tab par jao
2. Completed workflow run click karo
3. **Artifacts** section mein `ten-sports-live-hd-apk` download karo
4. ZIP extract karo → `.apk` file milegi
5. Phone par install karo! ✅

---

## Firebase Setup (Optional — channels live karne ke liye)

`config/firebase.ts` mein apna Firebase project config dalo:

```
apiKey: "TUMHARA_API_KEY"
databaseURL: "https://TUMHARA_PROJECT.firebaseio.com"
projectId: "TUMHARA_PROJECT_ID"
...
```

Firebase Realtime Database mein yeh structure rakho:

```json
{
  "categories": [
    { "id": "cricket", "name": "Cricket", "icon": "baseball", "color": "#e63946", "order": 1 }
  ],
  "channels": {
    "cricket": [
      {
        "id": "ch1",
        "name": "Star Sports 1",
        "logo": "https://logo-url.com/logo.png",
        "streamUrl": "https://tumhara-stream.m3u8",
        "isLive": true
      }
    ]
  }
}
```

---

## AdMob Setup

`components/BannerAd.tsx` aur `components/InterstitialAdOverlay.tsx` mein apna Ad Unit ID dalo:

```
ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY
```
